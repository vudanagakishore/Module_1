package sample;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class FactTest {

	@Test
	void test() 
	{
		factorial keyboard  = new factorial();
		int excepted = 120;
		int actual = keyboard.display();
		assertEquals(excepted,actual);
	}

}
