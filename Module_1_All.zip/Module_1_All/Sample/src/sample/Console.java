package sample;
import java.io.*;
public class Console               //RandomAccessFileDemo
{
	public void readRAF() throws IOException
	{
		try 
		{
			RandomAccessFile rafobj = new RandomAccessFile("C:\\filename/filename.txt","r");
			String a;
			while((a=rafobj.readLine())!= null)
			{
				System.out.println(a);
			}
			rafobj.close();
		}catch(Exception e) 
		{
			System.out.println(e);
		}
     }
	public void writeRAF() throws IOException
	{
		try 
		{
			RandomAccessFile rafobj = new RandomAccessFile("C:/filename/filename.txt","rw");
			rafobj.writeChars("Hello Everybody");
			rafobj.close();
		}
		catch(IOException e) 
		{
			System.out.println(e);
		}
	}
	public static void main(String [] args) throws IOException
	{
		Console keyboard = new Console();
		keyboard.readRAF();
		//keyboard.writeRAF();
		
	}
}
	
	
