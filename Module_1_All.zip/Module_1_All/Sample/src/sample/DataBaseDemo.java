package sample;

import java.sql.*;
import java.util.Scanner;
public class DataBaseDemo 
{
	public static void main(String args[])
	{
		Scanner s = new Scanner(System.in);
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "India123");
			
			PreparedStatement stmt  = con.prepareStatement("insert into sample values(?,?)");
			
			int a=s.nextInt();
			String g=s.next();
			stmt.setInt(1, a);
			stmt.setString(2,g);
			stmt.executeUpdate();
			System.out.println("record added succesfully");
			con.close();
			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
