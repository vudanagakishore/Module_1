package sample;


/*public class Lambda {

		public static void main(String [] args)
		{
			Sum s = (a,b) -> a+b;
			int x = s.calSum(23,23);
			System.out.println(x);
		}
	}

	interface Sum
	{
		int calSum(int x,int y);
	}
*/

/*public class Lambda
{
	public static void main(String [] args)
	{
		Sum s = (v) -> v+10;
		int x = s.calSum(23);
		System.out.println(x);
	}
}

interface Sum
{
	int calSum(int x);
}*/




public class Lambda
{
	public static void main(String [] args)
	{
		Sum s = () -> "HelloWorld";
		String x = s.calSum();
		System.out.println(x);
	}
}

interface Sum
{
	String calSum();
}



