
package sample;

/*class SampleOne
{
	void display()
	{
	int a = 10;
	int b = 20;
	a = a + b;
	b = a - b;
	a = a - b;
	System.out.printf("%d %d",a,b);
	}
}


public class Sample 
{
	public static void main(String[] args)
	{
		System.out.println("Hello World");
		SampleOne keyboard = new SampleOne();
		keyboard.display();
	}
}


*/

// this is for junit
class SampleOne
{
	int display()
	{
	int a = 10;
	int b = 20;
	a = a + b;
	b = a - b;
	a = a - b;
   return a;
	}
}


public class Sample 
{
	public static void main(String[] args)
	{
		System.out.println("Hello World");
		SampleOne keyboard = new SampleOne();
		int result = keyboard.display();
		System.out.println(result);
	}
}






