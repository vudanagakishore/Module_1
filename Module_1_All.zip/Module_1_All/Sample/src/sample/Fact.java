/*package sample;
//import java.util.Scanner;
public class Fact 
{
	public static void main(String[] args)
	{
		factorial keyboard = new factorial();
		keyboard.display();
	}
}


class factorial
{
	void display()
	{
		int fact=1;
		int i;
		for(i=1;i<=5;i++)
		{
			fact = fact * i;
			
		}System.out.println(fact);
	}
}*/



package sample;
//import java.util.Scanner;
public class Fact 
{
	public static void main(String[] args)
	{
		factorial keyboard = new factorial();
		int result = keyboard.display();
		System.out.println(result);
	}
}


class factorial
{
	int  display()
	{
		int fact=1;
		int i;
		for(i=1;i<=5;i++)
		{
			fact = fact * i;
		}
		return fact;
	}
}

