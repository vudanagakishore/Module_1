package sample;

import java.util.*;

public class Practice 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int num = keyboard.nextInt();
		Addition a = new Addition();
		int result = a.add(num);
		System.out.println(result);
		keyboard.close();
	}
}

class Addition
{
	int add(int n)
	{
		int sum = 0,rem;
		while(n!=0)
		{
		rem = n%10;
		sum = sum + rem;
		n = n/10;
		}
		return sum;
	}
}















//this is lab9-excercise2 problem in an other way

/*package lab9;
import java.util.*;

public class Excercise2 
{
	HashMap countCharacter(char[] ch)
	{
		HashMap<Character,Integer> a = new HashMap<Character,Integer>();
		int length = ch.length;
		int count = 0,flag = 0;
		for(int i=0;i<length;i++)
		{
			count=0;
			for(int j=0;j<length;j++)
				if(ch[j]==ch[i])
					
					count++;
			    for(int k=0;k<i;k++)
				    
			    	if (ch[k]== ch[i])
					
			    		 flag=1;
			        flag=0;
			a.put(ch[i],count);
		}
		return a;
   }
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		char ch[] = new char[50];
		ch = keyboard.next().toCharArray();
		Excercise2 e = new Excercise2();
		HashMap<Character,Integer> h = new HashMap<Character,Integer>();
		h = e.countCharacter(ch);
		for(Map.Entry mp:h.entrySet())
		{
			char key = (char)mp.getKey();
			Integer count = (Integer)mp.getValue();
			System.out.println(key+":"+count);
		}
	}
}*/