package sample;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class SampleTest {

	@Test
	void test() 
	{
		SampleOne keyboard = new SampleOne();
		int excepted = 30;
		int actual = keyboard.display();
		assertEquals(excepted,actual);
		
	}

}
