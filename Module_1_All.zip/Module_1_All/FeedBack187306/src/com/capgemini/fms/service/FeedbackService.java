package com.capgemini.fms.service;

import java.util.Map;

import com.capgemini.fms.dao.FeedbackDAO;
import com.capgemini.fms.exceptions.InvalidSubjectException;



public class FeedbackService  implements IFeedbackService
{
	 FeedbackDAO fbDaoObj;
	 
	 public FeedbackService()
	 {
		 fbDaoObj = new FeedbackDAO();
	 }
	 

	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject)  throws Exception
	{
		return fbDaoObj.addFeedbackDetails(name, rating, subject);
		// TODO Auto-generated method stub
		 
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		return null;
	}


	public boolean istopicValid(String topic) 
	{
		boolean b = false;
		if(topic == "Math" || topic == "English")
		{
			b=  true;
		}
		return b;
		//else
			
		//{
		//	throw new InvalidSubjectException();
		///}
	}


	public boolean isratingValid(int rating)
	{
		boolean b = false;
		if(rating<=0 || rating>5 )
			b = true;
		return b;
	}

}
