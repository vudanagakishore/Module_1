package com.capgemini.fms.ui;


import java.util.Scanner;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.FeedbackService;

public class Client 
{
	public static void main(String [] args)
	{
		Scanner scanobj = new Scanner(System.in);
		FeedbackService fbServiceObj = new FeedbackService();
		while(true)
		{
			System.out.println("1) Add Feedback\n"
					+ "2) Print Feedback Report\n"
					+ "3) Exit");
			int choice = scanobj.nextInt();
			switch(choice)
			{
			case 1:
				//System.out.println("1");
				Feedback fbobj = new Feedback();
				System.out.println("Enter Teacher Name");
				String teacherName = scanobj.nextLine();
				fbobj.setTeacherName(teacherName);
				System.out.println("Enter Subject Name");
				String topic = scanobj.nextLine();
				fbobj.setTopic(topic);
				System.out.println("Enter Rating");
				int rating = scanobj.nextInt();
				fbobj.setRating(rating);
				try {
					fbServiceObj.addFeedbackDetails(fbobj.getTeacherName(), fbobj.getRating(), fbobj.getTopic());
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println(" Feedback added");
				
				break;
			case 2:
				System.out.println("2");
				break;
			default:
				System.out.println("Exit");
				System.exit(0);
				break;
			}
		}
	}
}
