package com.bean;

public class Bean 
{
	String name;
	int id;
	int price;
	char grade;
	
	public Bean(String name2, int id2, int price2) 
	{
		name = name2;
		id = id2;
		price = price2;
	}

	public Bean(int id2) {
		// TODO Auto-generated constructor stub
		id = id2;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public char getGrade() {
		return grade;
	}

	public void setGrade(char grade) {
		this.grade = grade;
	}
	
	
}
