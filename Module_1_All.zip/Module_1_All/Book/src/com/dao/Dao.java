
/*
           Ends the project BookRecord
 */





package com.dao;

import com.bean.Bean;

public class Dao 
{
	Bean [] a = new Bean[10];
	public void dao(Bean b)
	{
		a[0] = b;
		System.out.println("added succesfully and details are given below");
		System.out.println(a[0].getName()+a[0].getId()+a[0].getPrice()+a[0].getGrade());
	}
	
	
	public void retrive(Bean b)
	{
		
	}
}                                                       