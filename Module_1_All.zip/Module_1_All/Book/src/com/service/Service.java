package com.service;

import com.bean.Bean;
import com.dao.Dao;

public class Service 
{	Dao d;
	public void service(Bean b)
	{
	
	  Bean be = calGrade(b);
	  System.out.println("details accepted");
	  d = new Dao();
	  d.dao(be);
	}
	
	
	public Bean calGrade(Bean b)
	{
		System.out.println("details accepted before cal");
		int cal = b.getPrice();
        char finalgrade;
		if(cal <1000)
		{
			finalgrade = 'A';
		}
		else
			finalgrade = 'B';
		b.setGrade(finalgrade);
		return b;
		
	}
	
	public void retrive(Bean b)
	{
		d.retrive(b);
	}
	
	
}

