package com.ui;

import java.util.*;

import com.bean.Bean;
import com.service.Service;

public class BookRecord 
{
	Scanner s;
	Bean b;
	Service se;
	public void addBook()
	{
		s = new Scanner(System.in);
		System.out.println("name");
		String name = s.nextLine(); //bookname
		System.out.println("id");
		int id = s.nextInt(); //bookid;
		System.out.println("price");
		int price  = s.nextInt();
		System.out.println("details accepted");
		b = new Bean(name,id,price);
		System.out.println("details accepted");
		se =new Service();
		se.service(b);
	}
	public void retrive() 
	{
		System.out.println("id");
		int id = s.nextInt(); //bookid;
		b = new Bean(id);
		se = new Service();
		se.retrive(b);
		
	}
}
