package com.ui;

import java.util.*;

import com.bean.Bean;
import com.service.Service;

public class BookRecord 
{
	Scanner s;
	Bean b;
	Service se;
	int a = 123456789;
	public BookRecord()
	{
		se =new Service();
	}
	
	
	public void addBook()
	{
		s = new Scanner(System.in);
		System.out.println("name");
		String name = s.nextLine(); //bookname
		//System.out.println("id");
		//int id = s.nextInt(); //bookid;
		System.out.println("price");
		int price  = s.nextInt();
		//System.out.println("details accepted");
		int vehicleid = (int)(Math.random()*34531);
		System.out.println("Book Id is:"+vehicleid);
		//System.out.println("details accepted");
		b = new Bean(name,price,vehicleid);
		se.service(b);
	}
	public void retrive() 
	{
		s = new Scanner(System.in);
		System.out.println("Enter The Bookid Which You Want To Retrive");
		int id = s.nextInt(); //bookid;
		//se =new Service();
		se.retrive(id);
		
		
	}


	public void allDetails() 
	{
		se.all();
		
	}

/*
	public void sortEmployeename() 
	{
		se.sorting();
	}*/
}
