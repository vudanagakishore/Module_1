package layer.ui;

import java.util.*;

public class Ui 
{
	public static void main(String [] args)
	{
		int n;
		System.out.println("Enter the choice");
		System.out.println("1.Add Record");
		System.out.println("2.Retrive Record");
		System.out.println("3.Delete Record");
		System.out.println("4.Exit");
		
		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		switch(a)
		{
		case 1:
			System.out.println("Add Record");
			break;
		case 2:
			System.out.println("Retrive Record");
			break;
		case 3:
			System.out.println("Delete Record");
			break;
		case 4:
			System.out.println("Exit");
			break;
		default : 
			System.out.println("wrong decision");
		}
		
		
	}

}
