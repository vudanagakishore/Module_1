package layer.ui;

import java.util.*;

public class Employee 

{
	public static void main()
	{
		Scanner keyboard = new Scanner(System.in);
		int employeeid = keyboard.nextInt();
		String name = keyboard.nextLine();
		float salary = keyboard.nextFloat();
		keyboard.close();
		
		
		
		
		
		
	}
}
