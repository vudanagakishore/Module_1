package lab5;
import java.util.*;
enum Traffic
{
	RED,GREEN,YELLOW;
}

public class Excercise1 
{
	Traffic colour;
	public Excercise1(Traffic colour)
	{
		this.colour = colour;
	}
	public void colour()
	{
		switch(colour)
		{
		case RED:
			System.out.println("STOP");
		    break;
		case GREEN:
			System.out.println("GO");
		    break;
		case YELLOW:
			System.out.println("READY");
		    break;
		    default:
		    	System.out.println("Wrong Selection");
		}
	}
	public static void main(String [] args)
	{
		Excercise1 keyboard = new  Excercise1(Traffic.GREEN);
		keyboard.colour();
	}
}