package lab5;
import java.util.*;

public class Excercise5 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int age = keyboard.nextInt();
		try 
		{
			if (age<15)
				throw new ExceptionAge("Invalid age");
			else
				System.out.println("valid age");
		}
		catch (ExceptionAge ea)
		{
			System.out.println(ea);
		}
		
	}
}

class ExceptionAge extends Exception
{
	public ExceptionAge(String str)
	{
		System.out.println(str);
	}
}