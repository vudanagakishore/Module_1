package lab8;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Excercise3
{
	public static void main(String [] args) throws IOException
	{
		Count keyboard = new Count();
		keyboard.raf();
	}
}


class Count
{
	int words = 0;
	int lines = 0;
	int characters = 0;
	public void raf() throws IOException
	{
		try {
			RandomAccessFile rafobj = new RandomAccessFile("C:\\filename/filename.txt","r");
			String s;
			while((s=rafobj.readLine())!=null)
				{
				  characters+=s.length();
				  String[] Wordlist = s.split("\\s+");
				  words+=Wordlist.length;
				  String[] sentencelist = s.split("[!?.:]+");
				  lines+=sentencelist.length;
				}
			System.out.println("words count= "+words+5);
			System.out.println("lines count= "+lines+1);
			System.out.println("characters count= "+characters+1);
		    }
		catch(Exception e)
		 {
			System.out.println(e);
		 }
	     }
}