package lab8;
import java.util.*;
public class Excercise5 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		String s = keyboard.nextLine();
	    Check c = new Check();
	    c.check(s);
	}
}

class Check
{
	void check(String a)
	{	
		int flag = 0;
		char ch[] = a.toCharArray();
		int length = ch.length;
		for(int i=0;i<length-1;i++)
		{
			char cha = ch[i];
			char b = ch[i+1];
			if(cha >= b)
			{
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			System.out.println("Given String is Positive String");
		}
		else
		{
			System.out.println("Given String is Not a Positive String");
		}
	}
}