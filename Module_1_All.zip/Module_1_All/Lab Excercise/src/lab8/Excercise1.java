package lab8;
import java.util.*;
public class Excercise1 
{
	public static void main(String [] args)
	{
		Scanner keyboard  = new Scanner(System.in);
		String a = keyboard.nextLine();
		StringTokenizer str = new StringTokenizer(a);
		int sum=0;
		while(str.hasMoreTokens())
		{
			int b =Integer.parseInt(str.nextToken());
			System.out.println(b);
			
			sum = sum+b;
		}
		System.out.println(sum);
	}
}
