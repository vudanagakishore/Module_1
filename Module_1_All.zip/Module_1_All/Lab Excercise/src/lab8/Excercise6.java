package lab8;
import java.util.*;
import java.time.*;
public class Excercise6 
{	void setDate(Date d)
	{
		System.out.println();
	}
	public static void main(String [] args)
	{
		LocalDate now  = LocalDate.now();
		System.out.println("Todays Date:" + " "+now);
	}
}
