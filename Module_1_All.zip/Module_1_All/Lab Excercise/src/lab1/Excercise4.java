package lab1;
import java.util.*;
public class Excercise4 
{
	public static void main(String[] args)
	{
		int number;
		boolean flag = false;
		Scanner keyboard = new Scanner(System.in);
		number = keyboard.nextInt();
		int currentDigit = number%10;{
		number = number/10;
		while(number>10) {
		   if(currentDigit<=number%10)
			   flag = true;
		   break;
		}
		currentDigit = number%10;
		number= number/10;
		if(flag) {
			System.out.println("not incresing");
		}
		else
		{
			System.out.println(" incresing");
		}
		}
	}
}
	