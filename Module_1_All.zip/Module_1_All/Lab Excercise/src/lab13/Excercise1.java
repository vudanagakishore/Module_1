package lab13;

import java.util.*;
import java.lang.Math;

public class Excercise1 {
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int c = keyboard.nextInt();
		int d = keyboard.nextInt();
		Sum s = (a,b) -> Math.pow(a,b);
		double x = s.calSum(c,d);
		System.out.println(x);
	}
}


interface Sum
{
double calSum(double x,double y);
}
