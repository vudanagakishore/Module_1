package lab9;
import java.util.*;

public class Excercise2 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		char ch[] = new char[50];
		ch = keyboard.next().toCharArray();
		Count c = new Count();
		HashMap<Character,Integer> h = new HashMap<Character,Integer>();
		h = c.countCharacter(ch);
		for(Map.Entry mp:h.entrySet())
		{
			char key = (char)mp.getKey();
			Integer count = (Integer)mp.getValue();
			System.out.println(key+":"+count);
		}
	}
}


class Count
{
	HashMap countCharacter(char[] ch)
	{
		HashMap<Character,Integer> a = new HashMap<Character,Integer>();
		int length = ch.length;
		int count = 0,flag = 0;
		for(int i=0;i<length;i++)
		{
			count=0;
			for(int j=0;j<length;j++)
				if(ch[i]==ch[j])
					
					count++;
			    for(int k=0;k<i;k++)
				    
			    	if (ch[k]== ch[i])
					
			    		 flag=1;
			flag=0;
			a.put(ch[i],count);
		}
		return a;
	}
}