package lab11;

import java.util.*;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class MusicPlayTask implements Runnable
{
	public void run()
	{
		System.out.println("Music play is executing");
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException e)
		{
			System.out.println("Music play exception");
		}
		System.out.println("Music play is again started after sleep");
	}
	
}

class CopyTask implements Runnable
{
	public void run()
	{
		System.out.println("Copy Task is executing");
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException e)
		{
			System.out.println("Copy Task exception");
		}
		System.out.println("Copy Task is started again  after sleep");
	}
}

public class Excercise1 
{
	public static void main(String [] args) 
	{
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter your choice 1.Executor  2.Executor Service  ");
		int choice = keyboard.nextInt();
		if(choice == 1 )
		{
			Executor e = Executors.newSingleThreadExecutor();
			e.execute(new MusicPlayTask());
			e.execute(new CopyTask());
		}
		else if(choice == 2)
		{
			ExecutorService e1 = Executors.newSingleThreadExecutor();
			ExecutorService e2 = Executors.newFixedThreadPool(8);
			e1.execute(new MusicPlayTask());
			e2.execute(new CopyTask());
			e1.shutdown();
			e2.shutdown();
		}
		else
			System.out.println("Not a valid choice");
	}
}
