package com.cg.eis.pl;
import java.util.*;
public class Main 
{

	public static void main(String args[])
	{ 
		int choice;
		CustomerDetails ad=new CustomerDetails();
		Scanner keyboard=new Scanner(System.in);
		
		
		do
		{
			 System.out.println("Specify your choice:");
			 choice = keyboard.nextInt();
			switch(choice)
			{
			case 1:
				ad.Add();
				break;
			case 2:
				ad.Retrieve();
				break;
			case 3:
				System.out.println(" Exit:");
				break;
			}
			
		}
		while(choice!=3);
		keyboard.close();
	}
}
