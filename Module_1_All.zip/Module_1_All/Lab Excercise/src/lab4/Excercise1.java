package lab4;
import java.util.*;
public class Excercise1 
{
	public static void main(String [] args)
	{
		Scanner keyboard = new Scanner(System.in);
		int a = keyboard.nextInt();
		int b = a;
		Arm kb = new Arm();
		int res =  kb.arm(b);
		System.out.println(res);
	}

}


class Arm
{
	int arm(int n)
	{
		int sum = 0;
		for(int i=1;i<=n;i++)
		{
			int rem = n%10;
			sum = sum + (rem*rem*rem);
			n = n/10;
		}
		return sum;
		
		
	}
}





/*int s = n*n*n;
		return s;*/