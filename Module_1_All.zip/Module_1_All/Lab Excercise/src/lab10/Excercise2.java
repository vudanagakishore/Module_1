package lab10;
import java.util.Date;
public class Excercise2 implements Runnable
{
    Thread t = new Thread(this);
    public Excercise2() throws InterruptedException
    {
    	t = new Thread(this);
    	t.start();
    }
    
    public void run()
    {
    	Date date;
    	while(true)
    	{
    		try 
    		{
    			date = new Date();
    			Thread.sleep(8000);
    			System.out.println(date.getHours()+ ":" + date.getMinutes()+ ":"+ date.getSeconds());
    		}
    		catch(InterruptedException e)
    		{
    			System.out.println("This is wrong");
    			
    		}
    	}
    }
    public static void main(String [] args) throws InterruptedException
    {
    	Excercise2 e = new Excercise2();
    }
}

