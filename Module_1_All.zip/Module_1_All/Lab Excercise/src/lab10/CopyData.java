package lab10;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
public class CopyData extends Thread
{
	FileInputStream fi;
	FileOutputStream fo;
	public CopyData(FileInputStream fi,FileOutputStream fo)
	{
		this.fi = fi;
		this.fo = fo;
	}
	public void run() 
	{
		try
		{
			int a;
			int i=0;
			while((a=fi.read()) != -1 )
			{
				fo.write(a);
				//int i=0
				i++;
				if(i%10==0)
				{
					System.out.println("10 Characters are copied");
					try {
						   sleep(1000);
					    }
					catch(InterruptedException e)
					{
						System.out.println("Wrong... ");
					}
				}
				
			}
			fi.close();
			fo.close();
			System.out.println("File copied successfully");
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
	}
	
	
}
