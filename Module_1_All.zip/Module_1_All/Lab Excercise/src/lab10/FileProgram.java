package lab10;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.*; 


public class FileProgram 
{
	public static void main(String [] args) throws IOException
	{
		try
		{
			FileInputStream fi = new FileInputStream("C:\\filename/source.txt");
			FileOutputStream fo = new FileOutputStream("C:\\filename/Destination.txt");
			CopyData c = new CopyData(fi,fo);
			c.start();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
      }
}
    