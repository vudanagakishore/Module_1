package com.cg.frs.dto;

public class FlatRegistrationDTO 
{
	int number;
	int flatType;
	int flatArea;
	float rent;
	float deposit;
	int flatId;
	
	public FlatRegistrationDTO(int number, int flatType, int flatArea, float rent, float deposit, int flatId) 
	{
		super();
		this.number = number;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rent = rent;
		this.deposit = deposit;
		this.flatId = flatId;
		
	}

	public FlatRegistrationDTO() {
		// TODO Auto-generated constructor stub
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public int getFlatType() {
		return flatType;
	}

	public void setFlatType(int flatType) {
		this.flatType = flatType;
	}

	public int getFlatArea() {
		return flatArea;
	}

	public void setFlatArea(int flatArea) {
		this.flatArea = flatArea;
	}

	public float getRent() {
		return rent;
	}

	public void setRent(float rent) {
		this.rent = rent;
	}

	public float getDeposit() {
		return deposit;
	}

	public void setDeposit(float deposit) {
		this.deposit = deposit;
	}

	public int getFlatId() {
		return flatId;
	}

	public void setFlatId(int flatId) {
		this.flatId = flatId;
	}

	@Override
	public String toString() {
		return "number=" + number + ", flatType=" + flatType + ", flatArea=" + flatArea + ", rent="
				+ rent + ", deposit=" + deposit + ", flatId=" + flatId;
	}
	
	
	
}
