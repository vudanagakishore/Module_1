package com.cg.frs.dao;

import java.util.ArrayList;
import java.util.HashMap;

import com.cg.frs.dto.FlatOwner;
import com.cg.frs.dto.FlatRegistrationDTO;

public class IFlatRegistrationDAOImpl implements IFlatRegistrationDAO 
{
	
	 HashMap<Integer,FlatOwner> owners  = new HashMap<>();
	 
	 public IFlatRegistrationDAOImpl()
	 {
		 owners.put(1,new FlatOwner(1,"Vaishali",902300212));
		 owners.put(2,new FlatOwner(2,"Vaishalik",902300212));
		 owners.put(3,new FlatOwner(3,"Vaishalil",902300212));
	 }
	
	 HashMap<Integer,RegistrationDetails> flatDetails = new HashMap();
	 
	 
	 
	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat) {
		// TODO Auto-generated method stub

		 
		
		return null;
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() {
		// TODO Auto-generated method stub
		return null;
	}

}
