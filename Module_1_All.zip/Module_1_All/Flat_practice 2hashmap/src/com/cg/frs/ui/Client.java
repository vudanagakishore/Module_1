package com.cg.frs.ui;

import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.service.IFlatRegistrationServiceImpl;

public class Client 
{
	public static void main(String [] args)
	{
		Scanner s = new Scanner(System.in);
		FlatRegistrationDTO flatDetails = new FlatRegistrationDTO();
		IFlatRegistrationServiceImpl IFlatRegistrationServiceImpl = new IFlatRegistrationServiceImpl();
		
		
		while(true)
		{
			System.out.println("1.Register Flat\n"
					+ "2.Display Flat Details\n"
					+ "3.Exit");
			int choice = s.nextInt();
			switch(choice)
			{
				case 1:
					//System.out.println("1");
					System.out.println("Existing Owner IDS Are: [1,2,3]");
					System.out.println("Please enter your owner Id from above list");
					int number = s.nextInt();
					System.out.println("Select Flat Type (1-1BHK, 2-2BHK)");
					int flatType = s.nextInt();
					System.out.println("Enter Flat Area in sq.ft.:");
					int flatArea = s.nextInt();
					System.out.println("Enter the desired rent amount Rs");
					float rent = s.nextFloat();
					System.out.println("Enter the desired deposit amount Rs");
					float deposit = s.nextFloat();
					int flatId = (int) (Math.random()*123);
					flatDetails = new FlatRegistrationDTO(number,flatType,flatArea,rent,deposit,flatId);
					IFlatRegistrationServiceImpl.registerFlat(flatDetails);
					break;
				case 2:
					System.out.println("2");
					break;
				default:
					System.out.println("3");
					System.exit(0);
				
			}
		}
		
	}
}
