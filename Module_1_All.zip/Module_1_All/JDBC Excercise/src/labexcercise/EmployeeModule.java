package labexcercise;

import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class EmployeeModule 
	{

		static Scanner sc = new Scanner(System.in);
		static int depositstatement;
		static int withdrawstatement;
		static String fromAccount;
		static String toAccount;
		static int transferAmount;
		static String empid;

		@Override
		public String toString() {
			// TODO Auto-generated method stub
			return super.toString();
		}

		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			int close = 0;
			PreparedStatement ps = null;
			ResultSet rs = null;


			Class.forName("oracle.jdbc.driver.OracleDriver");



			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "lab", "password");

			while (close == 0) {

				System.out.println("1. Create Account ");
				System.out.println("2. Show Info ");
				System.out.println("3. Update Info");
				System.out.println("4. Delete Info");
				System.out.println("5. Log out");
				System.out.println("Enter your choice :");

				int input = sc.nextInt();

				switch (input) {
				case 1:
					String Q_insert = "insert into EmployeeInfo(emp_id, name, salary, phone_no) values(?, ?, ?, ?)";

					System.out.println("Enter your Employee/Global ID : ");
					int accountno = sc.nextInt();

					System.out.println("Enter Your Name : ");
					String name = sc.next();

					System.out.println("Enter your salary : ");
					int salary = sc.nextInt();

					String phoneno = null;
					boolean phoneresult = false;
					while (phoneresult == false) {
						System.out.println("Enter your phone no : ");
						phoneno = sc.next();

						if (phoneno.length() == 10) {
							phoneresult = true;

						} else {
							System.out.println("Invalid length");
						}
					}

					ps = conn.prepareStatement(Q_insert); 
					ps.setInt(1, accountno); 
					ps.setString(2, name); 
					ps.setString(3, phoneno);
					ps.setInt(4, salary);

					int i = ps.executeUpdate(); 
					if (i == 1) {

						System.out.println("Account created successfully!");
					} else {
						System.out.println("Account creation failed!");
					}

					break;

				case 2:
					String Q_select = "select emp_id,name,salary,phone_no" + " from EmployeeInfo where emp_id = ?";
					ps = conn.prepareStatement(Q_select);
					System.out.println("Enter your Employee ID : ");
					empid = sc.next();

					ps.setString(1, empid); 
					rs = ps.executeQuery();
					while (rs.next()) {
						System.out.println("sadas2");
						int empId = rs.getInt(1);
						String empName = rs.getString(2);
						String EmpSalary = rs.getString(3);
						int Empphone_no = rs.getInt(4);

						System.out.println("Your ID : " + empId);
						System.out.println("Your Name : " + empName);
						System.out.println("Your Salary : " + EmpSalary);
						System.out.println("Your Phone No : " + Empphone_no);

					}

					break;

				case 3:
					System.out.println("Enter your Employee ID : ");
					empid = sc.next();
					String columnname;
					System.out.println("What you want to update ?\n1. Name\n2. Phone No");
					int choice = sc.nextInt();
					if (choice == 1) {
						columnname = "name";
					} else {
						columnname = "phone_no";
					}
					System.out.println("Enter new value :");
					String newValue = sc.next();

					String Q_update_2 = "update EmployeeInfo set " + columnname + " = ? where emp_id = ? ";
					ps = conn.prepareStatement(Q_update_2);

					ps.setString(1, newValue);
					ps.setString(2, empid);
					int update = ps.executeUpdate();
					if (update == 1) {
						System.out.println("Info Updated");
					} else {
						System.out.println("Sorry, Something went wrong!!");
					}

					break;
				case 4:

					System.out.println("Enter your Employee ID : ");
					empid = sc.next();
					String columnname2;
					System.out.println("What you want to delete ?\n1. Name\n2. Phone No");
					int choice2 = sc.nextInt();
					if (choice2 == 1) {
						columnname2 = "name";
					} else {
						columnname2 = "phone_no";
					}

					String Q_delete = "update EmployeeInfo set " + columnname2 + " = null where emp_id = ?";
					ps = conn.prepareStatement(Q_delete);

					ps.setString(1, empid);
					int update_2 = ps.executeUpdate();
					if (update_2 == 1) {
						System.out.println("Info Deleted");
					} else {
						System.out.println("Sorry, Something went wrong!!");
					}

					break;

				case 5:
					System.out.println("You have been successfully logged out");
					System.out.println("Do you want to exit ? press 0 to continue 1 to exit");
					close = sc.nextInt();
					if (close == 0) {
						close = 0;
					} else {
						System.exit(0);
					}

					break;

				default:
					System.out.println("Please enter valid choice!");

					break;

				}
				sc.close();
			}
		}
}
