package labexcercise2;

import java.util.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



public class AuthorModule {

	static Scanner sc = new Scanner(System.in);
	static String firstName, middleName, lastName, phoneNo;
	static int authorid, choice, update;
	static String columnname = null, newValue = null;

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		int close = 0;
		PreparedStatement ps = null;
		ResultSet rs = null;

	

		Class.forName("oracle.jdbc.driver.OracleDriver");


		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "lab", "password");

		while (close == 0) {

			System.out.println("1. Create Account ");
			System.out.println("2. Show Information ");
			System.out.println("3. Update Information");
			System.out.println("4. Delete Information");
			System.out.println("5. Books Information");
			System.out.println("6. Update Book Price");
			System.out.println("Enter your choice :");

			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				String Q_insert = "insert into Author(authorid, firstName, middleName, lastName,phoneNo,bookisbn) values(?, ?, ?, ?, ?, isbn_seq.nextval)";

				System.out.println("Enter your Author ID : ");
				authorid = sc.nextInt();

				System.out.println("Enter Your First Name : ");
				firstName = sc.next();

				System.out.println("Enter Your Middle Name : ");
				middleName = sc.next();

				System.out.println("Enter Your Last Name : ");
				lastName = sc.next();

				System.out.println("Enter your Phone No : ");
				phoneNo = sc.next();

				ps = conn.prepareStatement(Q_insert); 
				ps.setInt(1, authorid); 
				ps.setString(2, firstName); 
				ps.setString(3, middleName); 
				ps.setString(4, lastName);
				ps.setString(5, phoneNo);
		
				int i = ps.executeUpdate(); 
				if (i == 1) {

					System.out.println("Account created successfully!");
				} else {
					System.out.println("Account creation failed!");
				}

				break;

			case 2:

				String Q_select = "select authorid, firstName, middleName, lastName,phoneNo from Author where authorid = ?";
				ps = conn.prepareStatement(Q_select); 
				System.out.println("Enter your Author ID : ");
				authorid = sc.nextInt();

				ps.setInt(1, authorid);
				rs = ps.executeQuery();

		
				while (rs.next()) {
					authorid = rs.getInt(1);
					firstName = rs.getString(2);
					middleName = rs.getString(3);
					lastName = rs.getString(4);
					phoneNo = rs.getString(5);

					System.out.println("Your ID : " + authorid);
					System.out.println("Your Name : " + firstName);
					System.out.println("Your Middle : " + middleName);
					System.out.println("Your Last Name : " + lastName);
					System.out.println("Your Phone No : " + phoneNo + "\n");
				}

				break;

			case 3:
				System.out.println("Enter your Author ID : ");
				authorid = sc.nextInt();

				System.out
						.println("What you want to update ?\n1. First Name\n2. Middle Name\n3. Last Name\n4. PhoneNo");
				choice = sc.nextInt();
				if (choice == 1) {
					columnname = "firstName";
				} else if (choice == 2) {
					columnname = "middleName";
				} else if (choice == 3) {
					columnname = "lastName";
				} else if (choice == 4) {
					columnname = "phoneNo";
				} else {
					System.out.println("Enter a valid choice ");
				}

				System.out.println("Enter new value :");
				newValue = sc.next();

				String Q_update_2 = "update Author set " + columnname + " = ? where authorid = ? ";
				ps = conn.prepareStatement(Q_update_2);

				ps.setString(1, newValue);
				ps.setInt(2, authorid);
				update = ps.executeUpdate();
				if (update == 1) {
					System.out.println("Info Updated");
				} else {
					System.out.println("Sorry, Something  wrong!!");
				}
				break;
			case 4:
				System.out.println("Enter your Author ID : ");
				authorid = sc.nextInt();

				System.out
						.println("What you want to delete ?\n"
								+ "1. First Name\n"
								+ "2. Middle Name\n"
								+ "3. Last Name\n"
								+ "4. PhoneNo");
				choice = sc.nextInt();
				if (choice == 1) {
					columnname = "firstName";
				} else if (choice == 2) {
					columnname = "middleName";
				} else if (choice == 3) {
					columnname = "lastName";
				} else if (choice == 4) {
					columnname = "phoneNo";
				} else {
					System.out.println("Enter a valid choice ");
				}

				String Q_delete = "update Author set " + columnname + " = null where authorid = ? ";
				ps = conn.prepareStatement(Q_delete);

				ps.setInt(1, authorid);
				update = ps.executeUpdate();
				if (update == 1) {
					System.out.println("Information Updated");
				} else {
					System.out.println("Sorry, Something wrong!!");
				}

				break;

			case 5:
				System.out.println("Enter your Author ID : ");
				authorid = sc.nextInt();
				String showBookTitle = "select a.authorid,b.title from Author a, Book b where a.authorid = b.authorid";
				ps = conn.prepareStatement(showBookTitle);

				ResultSet resultSet = ps.executeQuery();

				while (resultSet.next()) {
					int i1 = 1;
					int id = resultSet.getInt(1);
					if (id == authorid) {
						String title = resultSet.getString(2);
						System.out.println(i1 + " " + title);
						i1++;
					}

				}

				break;

			case 6:
				System.out.println("Enter Author Name : ");
				String authorName = sc.next();

				System.out.println("Enter Author ID : ");
				authorid = sc.nextInt();

				String showBooks = "select a.authorid,b.title from Author a, Book b where a.authorid = b.authorid";
				ps = conn.prepareStatement(showBooks);

				ResultSet resultSet1 = ps.executeQuery();

				while (resultSet1.next()) {

					int id = resultSet1.getInt(1);
					if (id == authorid) {
						String title = resultSet1.getString(2);
						System.out.println(" " + title);

						System.out.println("Enter Book Name : ");
						String bookName = sc.next();
						System.out.println("Enter Price : ");
						int bookPrice = sc.nextInt();

						String updatePrice = "update Book set price = ? where title = ?";
						ps = conn.prepareStatement(updatePrice);

						ps.setInt(1, bookPrice);
						ps.setString(2, bookName);
						update = ps.executeUpdate();
						if (update == 1) {
							System.out.println("Price Updated!");
						} else {
							System.out.println("Operation Failed!");
						}
					}

				}

				break;
			default:
				System.out.println("Please enter valid choice!");

				break;

			}
		}
	}
}