package demo;

import java.util.regex.Pattern;

public class StringPatternMatchDemo1 {
	public static void main(String args[]) {
		String s1="helloeberybody";
		String s2=" HELLO EVERYBODY";
		boolean result=Pattern.matches(s1, s2);
		System.out.println(result);
	}

}
