package demo;

import java.util.concurrent.Callable;

public class DisplayTask implements Callable<String> {
	String message;
	DisplayTask(String message){
		this.message=message;
	}
	public String call() {
		return message;
	}
	

}
