package demo;

public class JoinThreadDemo {
static int counter=0;
public static void main(String args[]) {
	Thread t1=new Thread(new Runnable(){
		@Override
		public void run() {
			for(int i=0;i<100;i++)
			{
				counter++;
			}
		}
	});
	Thread t2=new Thread(new Runnable() {
		@Override
		public void run() {
			for(int i=0;i<500;i++)
			{
				counter++;
			}
		}
	});
	t1.start();
	t2.start();
try {
	t1.join();
	t2.join();
}
			catch(Exception e)
			{
				System.out.println(e);
			}
System.out.println("value:"+counter);
}


		
	

}

