package demo;

import java.io.Serializable;

public class ObjectReaderWrite  implements Serializable{
String str1,str2;
public ObjectReaderWrite(String s1,String s2) {
	str1=s1;
	str2=s2;
}
public String toString() {
	return str1+" "+str2;
}

}
