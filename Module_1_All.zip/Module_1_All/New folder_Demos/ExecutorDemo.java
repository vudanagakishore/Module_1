package demo;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class ExecutorDemo {
	public static void main(String args[]) {
		Executor e=Executors.newSingleThreadExecutor();
		e.execute(new MusicPlayTask());
		e.execute(new CopyTask());
		
		//MusicPlayTask m=new MusicPlayTask();
		//e.execute(m);
	}

}

