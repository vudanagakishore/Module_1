package demo;

import java.util.ArrayList;
import java.util.List;

public class CountCollectionDemo {
	public static void mian(String args[]) {
		List<Integer> MarkList=new ArrayList<Integer>();
		MarkList.add(12);
		MarkList.add(34);
		MarkList.add(89);
		MarkList.add(67);
		MarkList.add(36);
		MarkList.add(24);
		MarkList.add(45);
		System.out.println(MarkList);
long failedCount=MarkList.stream().filter(i->i<50).count();
System.out.println(failedCount);
	
	}
}
