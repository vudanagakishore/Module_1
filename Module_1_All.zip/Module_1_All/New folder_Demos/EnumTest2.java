package demo;
enum CupSize{
	SMALL(150),MEDIUM(300),LARGE(500);
	Integer mlt;
	CupSize(int ml){
		mlt=ml;
	}
	public String toString() {
		return mlt.toString();
	}
}
public class EnumTest2 {
	int a=90;
	String s="hello";
	public String toString() {
		return a+" "+s;
	}
	public static void main(String args[]) {
		CupSize cz[]=CupSize.values();
		for(CupSize cs:cz)
			System.out.println(cs.name()+" "+CupSize.valueOf(cs.name()));
		/*EnumTest2 et=new EnumTest2();
		System.out.println(et);*/
	}

}

