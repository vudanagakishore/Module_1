package demo;

public class ArrayDemo2 {
	public static void main(String args[]) {
		int a[]=new int[] {1,2,3,4,5};
		for(int i:a)
			System.out.println(i+" ");
		System.out.println("\n");
	}

}
