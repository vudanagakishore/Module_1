package com.cg.productmgmt.exception;

public class ProductException extends Exception
{
	public void EmployeeException() {
		
	}
	public void EmployeeException(String arg) {
		System.out.println(arg);
	}

	
}
