package com.cg.productmgmt.service;

import java.util.HashMap;
import java.util.Map;

import com.cg.productmgmt.dao.ProductDAO;
import com.cg.productmgmt.exception.ProductException;

public class ProductService implements IProductService
{
	ProductDAO d;
	
	public ProductService()
	{
		d = new ProductDAO();
	}

	@Override
	public int updateProducts(String Category, int hike) throws ProductException {
		// TODO Auto-generated method stub
		d.updateProducts(Category, hike);
		return 0;
	}

	@Override
	public Map<String, Integer> getProductDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isCategoryValid(String category) {
		// TODO Auto-generated method stub
		
		return false;
	}

	public boolean ishHikeValid(int hike) {
		// TODO Auto-generated method stub
		boolean b =false;
		if(hike>0)
		{
			b = true;
			return b;
		}
		return false;
	}
	

}