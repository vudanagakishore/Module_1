package com.cg.productmgmt.test;

import static org.junit.Assert.*;

import org.junit.Test;
import java.util.*;

import com.cg.productmgmt.exception.ProductException;


public class ProductDAOTest
{
    
}