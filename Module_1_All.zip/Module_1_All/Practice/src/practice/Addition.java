package practice;
import java.util.*;
public class Addition
{
	public static void main(String [] args)
	{
		//Scanner keyboard = new Scanner(System.in);
		//int a = keyboard.nextInt();
		//int b = keyboard.nextInt();
		Add kb = new  Add(10,20);
		int res = kb.add();
		System.out.println(res);
	}
}

class Add
{
	int x;   // frpm down it will come to here
	int y;   
	 Add (int a, int b)    // from the class intiliaze it will move to the paramterized constructor 
	{
		 x=a;
		 y=b;
	}
	int add()
	{
		int sum = x+y;
		return sum;
	}
}