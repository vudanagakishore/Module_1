class Test{
	int x=10;;

			
}
public class DemoArray {
	Test tObj[]=new Test[4];
	void init1() {
		
		Test t1=new Test();
		tObj[0]=t1;
		
	}
	void display() {
		System.out.println(tObj[0].x);
	}
	
	public static void main(String args[]) {
		
		DemoArray da=new DemoArray();
		da.init1();
		da.display();
		
		
	}

}
