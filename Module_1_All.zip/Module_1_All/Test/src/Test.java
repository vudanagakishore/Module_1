import java.util.*;

public class Test 
{
	
	public static void main(String [] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the username");
		String username = s.nextLine();
		System.out.println("Enter the password");
		String  password= s.nextLine();
		Bean b = new Bean(username,password);
	    Bean b =  b.dao(b);
	}
	
	

}
