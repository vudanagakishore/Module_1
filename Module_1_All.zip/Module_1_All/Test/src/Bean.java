public class Bean 
{
	Bean [] a = new Bean[10];
	String username1;
	String password1;
	public Bean(String username, String password) 
	{
		username1 = username;
		password1 = password;
	}
	
	
		public String getUsername1() {
		return username1;
	}


	public void setUsername1(String username1) {
		this.username1 = username1;
	}


	public String getPassword1() {
		return password1;
	}


	public void setPassword1(String password1) {
		this.password1 = password1;
	}


		public Bean dao(Bean b)
		{
			a[0] = b;
			System.out.println(a[0].username1+a[0].password1);
			return b;
			
		}
	
}
