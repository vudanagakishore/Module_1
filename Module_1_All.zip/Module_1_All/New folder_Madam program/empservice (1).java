package com.employeeService;
import com.employeeBean.*;
import com.employeeDao.*;
public class empservice {
	employeDao dao= new employeDao();
	
	public void adddetails(Methods method)
	{
		Methods methodadd = calculateinsurance(method);
		dao.datastore(methodadd);
	}
	public void retdetails(Methods meathod) 
	{
		dao.dataretrieve(meathod);
	}
	public void deldetails(Methods m) 
	{
		dao.datadelete(m);
	}
	public Methods calculateinsurance(Methods refsalary) 
	{
		float salary= refsalary.getEmployeesalary();
		float insuranceamt=0;
		if(salary>0&&salary<5000) 
		{
			insuranceamt=(float)(salary*0.05);
		}
		else if (salary>5000 && salary<10000)
		{
			insuranceamt=(float)(salary*0.10);
		}
		else if(salary>10000) 
		{
			insuranceamt=(float)(salary*0.15);
		}
		else 
		{
			System.out.println("enter valid salary.");
		}
		refsalary.setInsuranceamt(insuranceamt);
		return refsalary;
	}

}
