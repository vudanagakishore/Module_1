package com.employeeUi;
import java.util.Scanner;
public class Employee {
	public static void main(String args[]) {
		int ch;
		Scanner s = new Scanner(System.in);
		record record=new record();
		
		do {
			System.out.println("your choices");
			ch=s.nextInt();
		switch(ch) {
		case 1:
			record.addrecord();
			break;
		case 2:
			record.retrecord();
			break;
		case 3:
			record.delrecord();
			break;
		case 4:
			System.out.println("exit");
			break;
		}
		
		}
		while(ch !=4);
		s.close();
	}
	
	}
