package com.employeeUi;
import java.util.Scanner;
import com.employeeBean.*;
import com.employeeService.*;
public class record {
	empservice service = new empservice();

	public void addrecord() {
		
	System.out.println("enter the details:");
	Scanner s = new Scanner(System.in);
	System.out.println("ENTER ID:");
	int empid = s.nextInt();
	System.out.println("ENTER NAME:");
	String employeename=s.next();
	System.out.println("ENTER SALARY:");
	int employeesalary= s.nextInt();
	Methods bean= new Methods(empid,employeename,employeesalary);
	service.adddetails(bean);
	}
	public void retrecord() {
		Scanner s = new Scanner(System.in);
		System.out.println("ENTER ID:");
		int empid= s.nextInt();
		Methods bean= new Methods(empid);
		service.retdetails(bean);
	}
	public void delrecord() {
		Scanner s = new Scanner(System.in);
		System.out.println("ENTER ID:");
		int empid = s.nextInt();
		Methods bean= new Methods(empid);
		service.deldetails(bean);
		
	}

}