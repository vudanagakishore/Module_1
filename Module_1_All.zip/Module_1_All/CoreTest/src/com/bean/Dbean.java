package com.bean;

public class Dbean 
{

	private int distributorId;
	private String name;
	private int mobile;
	public Dbean(int id1, String name1, int mobile1) 
	{
		 distributorId = id1;
		 name = name1;
		 mobile = mobile1;
		
	}
	public int getDistributorId() {
		return distributorId;
	}
	public void setDistributorId(int distributorId) {
		this.distributorId = distributorId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	@Override
	public String toString() {
		return "Dbean [distributorId=" + distributorId + ", name=" + name + ", mobile=" + mobile + "]";
	}
	
}
