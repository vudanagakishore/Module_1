package com.service;


import com.bean.Bean;
import com.dao.VehicleDao;

public class Service 
{
	VehicleDao d;
	Bean b;
	public Service() 
	{
	
	 b = new Bean();
	 d=new VehicleDao();
	}
	public void vehicleService(Bean b)
	{
		d.vehicleDetails(b);
		
	}
	
	public void retriveVehicleService(int id)
	{	
		if(d.getDetails().containsKey(id))
		{
              b = (Bean) d.getDetails().get(id);
			System.out.print(b.getVehicleId()+b.getModelName()+b.getPrice());
		}
	}
}


//b = new Bean();
		/*d =new VehicleDao();
		if(d.getDetails().containsKey(id))
		{
			b = d.getDetails();
			System.out.println(b.getVehicleId()+);
		}*/
		