package com.service;

import com.bean.Bean;
import com.bean.Dbean;
import com.dao.DistributorDao;

public class Dservice {
	DistributorDao dd;
	Dbean d;
	public Dservice()
	{
	 dd = new DistributorDao();
	
	}

	public void dservice(Dbean d) {
		// TODO Auto-generated method stub
		dd.addDetails(d);
		
	}

	public void distributorservice(int mobile) 
	{
		if(dd.getDistributor().containsKey(mobile))
		{
              d = (Dbean) dd.getDistributor().get(mobile);
			System.out.print(d.getDistributorId()+d.getName()+d.getMobile());
		}
	}
		
	}

