package com.dao;

import java.util.HashMap;

import com.bean.Bean;

public class VehicleDao 
{	

	HashMap<Integer,Bean> hm = new HashMap<Integer,Bean>();

	public void vehicleDetails(Bean b)
	{
		hm.put(b.getVehicleId(), b);
		System.out.println(hm);
		
		//a[0] = b; 
		//System.out.println("vehicledetails DAO"+a[0].getVehicleId()+a[0].getModelName()+a[0].getPrice());
		///=a[0];
		//System.out.println("vehicleDetails"+b1);
		
	}
	

	public HashMap getDetails()
	{
		return hm;
		
	}
}




//Bean [] a =new Bean[10];
//Bean b1;

//a[0]=new Bean();

/*		System.out.println("Yes");
System.out.println(b1.getVehicleId()+b1.getModelName()+b1.getPrice());
int i=a[0].getVehicleId();
//System.out.println(i);
//int res;
//int res1;
//System.out.println( res = b.getVehicleId());
//System.out.println("Yes1");
//System.out.println( res1 = a[0].getVehicleId());

if(a[0].getVehicleId().equals(b.getVehicleId()))
{
	System.out.println("om");
}
*/
	