package com.ui;

import java.util.Scanner;

public class Main 
{
	public static void main(String [] args)
	{
		Scanner s = new Scanner(System.in);
		Vehicle v= new Vehicle();
		Distributor i = new Distributor();
		
		while(true)
		{
			
			System.out.println("Choice The Option from below menu");
			System.out.println("1.AddVehicledetail\n"
					+ "2.RetriveVehicledetail\n"
					+ "3.AddDistributordetail\n"
					+ "4.RetriveDistributordetail\n"
					+ "5.AddVehicleDistributor\n"
					+ "6.Exit");
			int choice =  s.nextInt();
			switch(choice)
			{
			case 1:
				//System.out.println("1");
				v.vehicleDetails();
				break;
			case 2:
				//System.out.println("2");
				v.retiveVehicleDetails();
				break;
			case 3:
				//System.out.println("3");
				i.DistributorDetails();
				break;
			case 4:
				System.out.println("4");
				i.retriveDistributor();
				break;
			case 5:
				System.out.println("5");
			default:
				System.out.println("Your Are Exited");
				System.exit(0);
			}
			
		}
	}
}
