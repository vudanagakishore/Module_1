package com.ui;

import java.util.*;

import com.bean.Bean;
import com.service.Service;
public class Vehicle 
{
	Scanner s;
	Service se;
	Bean b;
	public Vehicle(){
		se = new Service();
	}
	public void vehicleDetails()
	{
		s = new Scanner(System.in);
		System.out.println("Enter the Car Details");
		System.out.println("Enter the vehicle Id");
		int id = s.nextInt();
		System.out.println("Enter the Model Name");
		String name = s.next();
		System.out.println("Enter the Price");
		int price = s.nextInt();
		b = new Bean(id,name,price);
		
		se.vehicleService(b);
		
	}
	
	public void retiveVehicleDetails()
	{
		s = new Scanner(System.in);
		System.out.println("Enter the vehicle Id");
		int id = s.nextInt();
		se.retriveVehicleService(id);
		
	}
}
