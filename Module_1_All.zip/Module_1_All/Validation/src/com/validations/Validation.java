package com.validations;
import java.util.*;

/**
 * @author 
 * Syntax For Checking The First Letter Is Capital Or Not And Length is Greater Than 3 Or Not 
 */

public class Validation 
{

	Scanner s;
	public boolean validation(String name) 
	{
			
			while(true)
			{	
			if(Character.isUpperCase(name.charAt(0)) && name.length()>=3)
				{
					return true;
				}
			else
				{
					System.out.println("Enter the name ");
					s = new Scanner(System.in);
					name = s.nextLine();
				}
		
		
			}
			
	}
	
	
	
	/**
	 * @author 
	 *Syntax For Checking The Salary Is Greater Than 0 or not
	 */
	
	
	
 public boolean validationsalary(int salary)
	{

		while(true)
		{	
		if(salary > 0)
			{
				return true;
			}
		else
			{
				System.out.println("Enter the salary ");
				s = new Scanner(System.in);
				salary = s.nextInt();
			}
	
	
		}
		
	}
 
 
 /**
  * @author 
  * Syntax For Checking The Mobile Number Is Correct Or Not
  * Note : Taking Input As Integer And Converting Into String And Then Counting The Length 
  */


	public boolean validationnumber(String mobile) 
	{

		while(true)
		{
			
		if(mobile.length()==10)
		{

	        return true;
		}
		else
		{
			System.out.println("Enter the mobilenumber");
			s = new Scanner(System.in);
			mobile = s.next();
		}
	}
  }
}
