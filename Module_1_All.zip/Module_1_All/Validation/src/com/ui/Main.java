package com.ui;

import java.util.*;

import com.validations.Validation;

/**
 * @author Validation
 *
 */


public class Main
{
	
	
	
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		Validation v = new Validation();
		System.out.println("name");
		String name = s.nextLine();
		v.validation(name);
		System.out.println("salary");
		int salary = s.nextInt();
		v.validationsalary(salary);
		System.out.println(Integer.MAX_VALUE);
		System.out.println("mobile");
		int mobile = s.nextInt();
		String num=Integer.toString(mobile);
		v.validationnumber(num);
		System.out.println("task completed");
	}

}
