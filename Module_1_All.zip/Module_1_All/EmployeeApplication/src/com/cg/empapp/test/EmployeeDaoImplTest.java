package com.cg.empapp.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.junit.Test;

public class EmployeeDaoImplTest {
	@Test
	public void test() {
		HashMap map=new HashMap();
		List l=new ArrayList();
		assert(map instanceof HashMap);
		
		
		
		
	}

	
}
