package exception;

public class EmpException extends Exception
{
	public EmpException()
	{
		
	}
	
	public EmpException(String message)
	{
		super(message);
	}
}
