package dao;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashMap;

import org.junit.jupiter.api.Test;

import bean.Bean;

class DaoTest {

	@Test
	void test() 
	{
		Bean b = new Bean();
		//Dao d = new Dao();
		HashMap<Integer,Bean> map = new HashMap<Integer,Bean>();
		map.put(4, b);
		//
	}

}
